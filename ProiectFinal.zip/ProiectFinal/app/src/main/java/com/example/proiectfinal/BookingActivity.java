package com.example.proiectfinal;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.content.DialogInterface;
import android.app.AlertDialog;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import java.util.Calendar;
import java.util.List;
import java.util.Arrays;


public class BookingActivity extends AppCompatActivity {

    private EditText editTextEventDate, editTextNumberOfGuests, editTextLocation;
    private Spinner spinnerEventType, spinnerServiceType;
    private CheckBox checkBoxCustomAlbum;
    private Button buttonBookEvent;


    // Presupunem că avem emailul utilizatorului curent
    private String currentUserEmail = "user@example.com";// Acesta trebuie să fie emailul utilizatorului autentificat
    private ImageButton buttonHamburger;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        // Inițializarea componentelor UI
        spinnerEventType = findViewById(R.id.spinnerEventType);
        editTextNumberOfGuests = findViewById(R.id.editTextNumberOfGuests);
        editTextLocation = findViewById(R.id.editTextLocation);
        spinnerServiceType = findViewById(R.id.spinnerServiceType);
        checkBoxCustomAlbum = findViewById(R.id.checkBoxCustomAlbum);
        editTextEventDate = findViewById(R.id.editTextEventDate);
        buttonBookEvent = findViewById(R.id.buttonBookEvent);

        // Liste Servicii
        setupSpinners();
        setupDatePicker();


        buttonHamburger = findViewById(R.id.buttonHamburger);
        buttonHamburger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Deschide UserActivity când butonul hamburger este apăsat
                Intent intent = new Intent(BookingActivity.this, useractivity.class);
                startActivity(intent);
            }
        });

        // Inițializare și listener pentru butonul de rezervare
        buttonBookEvent = findViewById(R.id.buttonBookEvent);
        buttonBookEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBookEventClicked();
            }
        });
    }
    private void setupSpinners() {
        // Configurarea Spinner-ului pentru Tipul Evenimentului
        ArrayAdapter<CharSequence> eventTypeAdapter = ArrayAdapter.createFromResource(this,
                R.array.event_types_array, android.R.layout.simple_spinner_item);
        eventTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerEventType.setAdapter(eventTypeAdapter);

        // Configurarea Spinner-ului pentru Tipul de Servicii
        ArrayAdapter<CharSequence> serviceTypeAdapter = ArrayAdapter.createFromResource(this,
                R.array.service_types_array, android.R.layout.simple_spinner_item);
        serviceTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerServiceType.setAdapter(serviceTypeAdapter);

        // Logica pentru afișarea sau ascunderea CheckBox-ului
        spinnerServiceType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedService = parent.getItemAtPosition(position).toString();
                checkBoxCustomAlbum.setVisibility(selectedService.equals("Foto+Video") || selectedService.equals("Foto") ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                checkBoxCustomAlbum.setVisibility(View.GONE);
            }
        });
    }

    private void setupDatePicker() {
        editTextEventDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(v);
            }
        });
    }

    public void showDatePickerDialog(View view) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                String selectedDate = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
                editTextEventDate.setText(selectedDate);
            }
        }, year, month, day);
        datePickerDialog.show();
    }

    private void onBookEventClicked() {
        if (!validateFormData()) {
            return;
        }

        String eventType = spinnerEventType.getSelectedItem().toString();
        int numberOfGuests = Integer.parseInt(editTextNumberOfGuests.getText().toString());
        String location = editTextLocation.getText().toString();
        String serviceType = spinnerServiceType.getSelectedItem().toString();
        String eventDate = editTextEventDate.getText().toString();
        boolean isCustomAlbum = checkBoxCustomAlbum.isChecked();

        int totalCost = calculateTotalCost(serviceType, numberOfGuests, isCustomAlbum);

        showSummaryDialog(eventType, numberOfGuests, location, serviceType, eventDate, isCustomAlbum, totalCost);
    }

    private void showSummaryDialog(String eventType, int numberOfGuests, String location, String serviceType, String eventDate, boolean isCustomAlbum, int totalCost) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.summary_dialog_layout, null);

        CheckBox checkBoxCashPayment = dialogView.findViewById(R.id.checkBoxCashPayment);
        CheckBox checkBoxTermsConditions = dialogView.findViewById(R.id.checkBoxTermsConditions);
        TextView textViewTotalCost = dialogView.findViewById(R.id.textViewTotalCost);
        TextView textViewServices = dialogView.findViewById(R.id.textViewServices);

        String services = "Servicii selectate: " + serviceType;
        if (isCustomAlbum) {
            services += ", Album Personalizat";
        }
        textViewServices.setText(services);

        String costText = "Suma de plată: " + totalCost + " RON";
        if (numberOfGuests > 200 && serviceType.equals("Foto+Video") && isCustomAlbum) {
            costText += " (cu 5% discount inclus)";
        }
        textViewTotalCost.setText(costText);

        new AlertDialog.Builder(this)
                .setView(dialogView)
                .setTitle("Sumar Rezervare")
                .setCancelable(false)
                .setPositiveButton("Rezervă Acum", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (checkBoxCashPayment.isChecked() && checkBoxTermsConditions.isChecked()) {
                            if (isDateAvailable(eventDate)) {
                                saveEventDetails(eventDate, eventType, numberOfGuests, location, serviceType, isCustomAlbum, currentUserEmail);
                                Toast.makeText(BookingActivity.this, "Eveniment rezervat cu succes pentru " + eventDate, Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(BookingActivity.this, "Vă rugăm să acceptați termenii și condițiile & să alegeți o metodă de plată!.", Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }


    private boolean validateFormData() {
        // Verifică dacă data evenimentului a fost setată
        if (editTextEventDate.getText().toString().isEmpty()) {
            Toast.makeText(this, "Vă rugăm să selectați o dată pentru eveniment", Toast.LENGTH_LONG).show();
            return false;
        }

        // Verifică dacă numărul de persoane este introdus și este un număr valid
        String numberOfGuestsStr = editTextNumberOfGuests.getText().toString();
        if (numberOfGuestsStr.isEmpty() || Integer.parseInt(numberOfGuestsStr) <= 0) {
            Toast.makeText(this, "Vă rugăm să introduceți un număr valid de persoane", Toast.LENGTH_LONG).show();
            return false;
        }

        // Verifică dacă locația a fost setată
        if (editTextLocation.getText().toString().isEmpty()) {
            Toast.makeText(this, "Vă rugăm să introduceți locația evenimentului", Toast.LENGTH_LONG).show();
            return false;
        }

        // Adaugă aici orice alte validări necesare

        return true; // Datele sunt valide
    }


    private boolean isDateAvailable(String selectedDate) {
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        String savedReservations = sharedPreferences.getString("savedEventDates", "");
        List<String> allReservations = Arrays.asList(savedReservations.split(","));

        for (String reservation : allReservations) {
            String[] parts = reservation.split(":");
            if (parts.length == 2 && parts[0].equals(selectedDate)) {
                // Dacă data este deja rezervată
                new AlertDialog.Builder(this)
                        .setTitle("Data Indisponibilă!")
                        .setMessage("Data selectată este deja ocupată! Vă rugăm să alegeți o altă dată!")
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
                return false;
            }
        }
        return true;
    }

    private void saveEventDetails(String eventDate, String eventType, int numberOfGuests, String location, String serviceType, boolean isCustomAlbum, String userEmail) {
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPreferences.edit();

        String newReservation = eventDate + ":" + userEmail;
        String existingReservations = sharedPreferences.getString("savedEventDates", "");

        if (!existingReservations.isEmpty()) {
            newReservation = existingReservations + "," + newReservation;
        }

        myEdit.putString("savedEventDates", newReservation);
        myEdit.apply();
    }

    private int calculateTotalCost(String serviceType, int numberOfGuests, boolean isCustomAlbum) {
        int baseCost = 0; // Configurați costul de bază aici
        int costPerGuest = 50; // Exemplu de cost per persoană
        int albumCost = isCustomAlbum ? 200 : 0; // Cost suplimentar pentru album personalizat
        int totalCost = baseCost + (numberOfGuests * costPerGuest) + albumCost;

        // Aplică un discount de 5% dacă sunt îndeplinite condițiile
        if (numberOfGuests > 200 && serviceType.equals("Foto+Video") && isCustomAlbum) {
            totalCost = totalCost - (int)(totalCost * 0.05); // Reducere de 5%
        }

        return totalCost;
    }

}
