package com.example.proiectfinal;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import java.util.Map;



public class RegisterActivity extends AppCompatActivity {

    private EditText editTextName;
    private EditText editTextFirstName;
    private EditText editTextPhone;
    private EditText editTextEmail;
    private EditText editTextPassword;
    private EditText editTextConfirmPassword;
    private Button buttonRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Inițializarea componentelor UI
        editTextName = findViewById(R.id.editTextName);
        editTextFirstName = findViewById(R.id.editTextFirstName);
        editTextPhone = findViewById(R.id.editTextPhone);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        buttonRegister = findViewById(R.id.buttonRegister);

        // Setarea acțiunii pentru butonul de înregistrare
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateForm()) {
                    // Procesați înregistrarea utilizatorului aici
                    registerUser();
                }
            }
        });
    }

    // Metoda pentru validarea formularului
    private boolean validateForm() {
        // Obțineți valorile din câmpurile de text
        String name = editTextName.getText().toString();
        String firstName = editTextFirstName.getText().toString();
        String phone = editTextPhone.getText().toString();
        String email = editTextEmail.getText().toString();
        String password = editTextPassword.getText().toString();
        String confirmPassword = editTextConfirmPassword.getText().toString();

        // Verificați dacă câmpurile sunt completate
        if (name.isEmpty() || firstName.isEmpty() || phone.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, "Toate Campurile sunt obligatorii asa ca hai!", Toast.LENGTH_SHORT).show();
            return false;
        }

        // Verificați dacă parola și confirmarea parolei sunt identice
        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Parolele nu prea seamana..", Toast.LENGTH_SHORT).show();
            return false;
        }
        // Dacă toate verificările sunt trecute, returnați true
        return true;
    }

    // Metoda pentru înregistrarea utilizatorului
    private void registerUser() {
        String name = editTextName.getText().toString();
        String firstName = editTextFirstName.getText().toString();
        String phone = editTextPhone.getText().toString();
        String email = editTextEmail.getText().toString();
        String password = editTextPassword.getText().toString();

        // Obțineți instanța SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPreferences.edit();

        // Verificați dacă emailul sau telefonul există deja
        if (userExists(email, phone, sharedPreferences)) {
            Toast.makeText(this, "Un utilizator cu acest email & număr de telefon există deja", Toast.LENGTH_SHORT).show();
            return;
        }
        // Verificați dacă numărul de telefon este valid
        if (!phone.matches("[0-9]{10}")) {
            Toast.makeText(this, "Ai gresit putin la numar ia dute si verifica", Toast.LENGTH_SHORT).show();
            return ;
        }

        // Verificați dacă emailul este în format valid
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Adresa de email nu e validă!", Toast.LENGTH_SHORT).show();
            return ;
        }

        // Salvați datele utilizatorului dacă nu există duplicat
        myEdit.putString("Name", name);
        myEdit.putString("FirstName", firstName);
        myEdit.putString("Phone", phone);
        myEdit.putString("Email", email);
        myEdit.putString("Password", password); // Atenție: nu este sigur să stocați parole în SharedPreferences

        // Aplicați schimbările
        myEdit.apply();

        // Afișați un mesaj de succes
        Toast.makeText(this, "Înregistrare reușită!", Toast.LENGTH_SHORT).show();

        // Redirecționați către ecranul de autentificare
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    private boolean userExists(String email, String phone, SharedPreferences sharedPreferences) {
        // Verificați dacă emailul sau telefonul există deja în SharedPreferences
        // Aceasta este o metodă simplificată și nu este optimă pentru seturi mari de date
        Map<String, ?> allEntries = sharedPreferences.getAll();
        for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
            if (entry.getKey().contains("Email") && entry.getValue().toString().equals(email)) {
                return true;
            }
            if (entry.getKey().contains("Phone") && entry.getValue().toString().equals(phone)) {
                return true;
            }
        }
        return false;
    }

}

