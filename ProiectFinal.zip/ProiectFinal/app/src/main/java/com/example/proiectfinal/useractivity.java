package com.example.proiectfinal;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class useractivity extends AppCompatActivity {

    private Button buttonAccountDetails;
    private Button buttonBookings;
    private Button buttonLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.useractivity);

        buttonAccountDetails = findViewById(R.id.buttonAccountDetails);
        buttonBookings = findViewById(R.id.buttonBookings);
        buttonLogout = findViewById(R.id.buttonLogout);

        buttonAccountDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPasswordDialog();
            }
        });

        buttonBookings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showBookings();
            }
        });

        buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logout();
            }
        });

    }

    private void showPasswordDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Introduceți Parola Contului!");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        builder.setView(input);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String password = input.getText().toString();
                if (verifyPassword(password)) {
                    showAccountDetails();
                } else {
                    Toast.makeText(useractivity.this, "Parolă incorectă!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Anulează", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    private boolean verifyPassword(String password) {
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        String registeredPassword = sharedPreferences.getString("Password", null);

        return password.equals(registeredPassword);
    }

    private void showAccountDetails() {
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        String name = sharedPreferences.getString("Name", "N/A");
        String surname = sharedPreferences.getString("FirstName", "N/A");
        String email = sharedPreferences.getString("Email", "N/A");
        String phone = sharedPreferences.getString("Phone", "N/A");

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Detalii Cont");
        builder.setMessage("Nume: " + name + "\nPrenume: " + surname + "\nEmail: " + email + "\nTelefon: " + phone);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }


    private void showBookings() {
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        String existingReservations = sharedPreferences.getString("savedEventDates", "");

        StringBuilder bookingsBuilder = new StringBuilder();
        if (!existingReservations.isEmpty()) {
            // Separăm rezervările
            String[] reservations = existingReservations.split(",");
            for (String reservation : reservations) {
                // Fiecare rezervare este în formatul definit mai sus
                String[] parts = reservation.split(":");
                if (parts.length >= 7) {
                    // Adaugă detaliile în StringBuilder
                    bookingsBuilder.append("Data: ").append(parts[0])
                            .append("\nTip Eveniment: ").append(parts[1])
                            .append("\nNumăr Persoane: ").append(parts[2])
                            .append("\nLocație: ").append(parts[3])
                            .append("\nTip Serviciu: ").append(parts[4])
                            .append("\nAlbum Personalizat: ").append(parts[5])
                            .append("\n\n");
                }
            }
        }

        String bookings = bookingsBuilder.length() > 0 ? bookingsBuilder.toString() : "Nu există rezervări!";

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Rezervările Mele");
        builder.setMessage(bookings);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }

    private void logout() {
        // Resetează doar starea de autentificare
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("IsLoggedIn", false);
        editor.apply();

        // Redirecționează către ecranul de login și curăță stiva de activități
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish(); // Închide UserActivity
    }




}
