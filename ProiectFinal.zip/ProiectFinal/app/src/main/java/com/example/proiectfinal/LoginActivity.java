package com.example.proiectfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;





public class LoginActivity extends AppCompatActivity {

    private EditText editTextEmailOrPhone;
    private EditText editTextPassword;
    private Button buttonLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextEmailOrPhone = findViewById(R.id.editTextEmailLogin);
        editTextPassword = findViewById(R.id.editTextPasswordLogin);
        buttonLogin = findViewById(R.id.buttonLogin);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String identifier = editTextEmailOrPhone.getText().toString();
                String password = editTextPassword.getText().toString();

                if (validateCredentials(identifier, password)) {
                    // Utilizator autentificat cu succes
                    Toast.makeText(LoginActivity.this, "Autentificare reușită", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(LoginActivity.this, BookingActivity.class);
                        startActivity(intent);
                } else {
                    // Autentificare eșuată
                    Toast.makeText(LoginActivity.this, "Email,număr de telefon sau parolă incorectă!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean validateCredentials(String identifier, String password) {
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        String registeredPassword = sharedPreferences.getString("Password", null);
        String registeredEmail = sharedPreferences.getString("Email", null);
        String registeredPhone = sharedPreferences.getString("Phone", null);

        return (identifier.equals(registeredEmail) || identifier.equals(registeredPhone)) && password.equals(registeredPassword);
    }
}
